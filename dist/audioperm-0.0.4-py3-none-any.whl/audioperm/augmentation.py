"""
all the augmentation
"""